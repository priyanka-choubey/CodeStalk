package com.example.kaivalyamendki.sycodestalk;

/**
 * Created by Kaivalya Mendki on 03-04-2018.
 */

public class NewFollowing {

    String followingId;

    public NewFollowing() {}

    public NewFollowing(String followingId){
        this.followingId = followingId;
    }

    public String getFollowerId(){ return followingId; }
}
