package com.example.kaivalyamendki.sycodestalk;

/**
 * Created by Kaivalya Mendki on 03-04-2018.
 */

public class NewFollower {

    String followerId;

    public NewFollower() {}

    public NewFollower(String followerId){
        this.followerId = followerId;
    }

    public String getFollowerId(){ return followerId; }
}
